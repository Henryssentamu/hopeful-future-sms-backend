"""NCDC higher-secondary subject menu, checked 2026-10-01.

Source: https://ncdc.go.ug/directorates/ (Higher Secondary Education).
Categories are school-editable browsing aids, not UNEB combination rules.
NCDC-AL codes are internal identifiers, not examination subject codes.
Existing paper definitions are retained; no examination papers are guessed.
"""
from django.db import transaction

from apps.core.models import AcademicPeriod
from .models import Subject

SUBJECTS = [
    ('Agriculture', 'Sciences'),
    ('Biology', 'Sciences'),
    ('Chemistry', 'Sciences'),
    ('Mathematics', 'Sciences'),
    ('Physics', 'Sciences'),
    ('Subsidiary Mathematics', 'Sciences'),
    ('Art and Design', 'Arts'),
    ('Christian Religious Education', 'Arts'),
    ('Economics', 'Arts'),
    ('Entrepreneurship Education', 'Arts'),
    ('Geography', 'Arts'),
    ('History', 'Arts'),
    ('Islamic Religious Education', 'Arts'),
    ('Literature', 'Arts'),
    ('Music', 'Arts'),
    ('Arabic', 'Languages'),
    ('Chinese', 'Languages'),
    ('French', 'Languages'),
    ('German', 'Languages'),
    ('Kiswahili', 'Languages'),
    ('Latin', 'Languages'),
    ('Ateso', 'Languages'),
    ('Dhopadhola', 'Languages'),
    ('Leb Acoli', 'Languages'),
    ('Leblango', 'Languages'),
    ('Luganda', 'Languages'),
    ('Lugbarati', 'Languages'),
    ('Lumasaaba', 'Languages'),
    ('Lusoga', 'Languages'),
    ('Runyoro-Rutooro', 'Languages'),
    ('Runyankore-Rukiga', 'Languages'),
    ('Clothing and Textile', 'Technical'),
    ('Foods & Nutrition', 'Technical'),
    ('Metal Work', 'Technical'),
    ('Subsidiary ICT', 'Technical'),
    ('Technical Drawing', 'Technical'),
    ('Wood Work', 'Technical'),
    ('Principal ICT', 'Technical'),
    ('General Paper', 'General'),
    ('Physical Education', 'General'),
]
ALIASES = {
    "Christian Religious Education": ["CRE", "Christian Religious Education (CRE)"],
    "Islamic Religious Education": ["IRE", "Islamic Religious Education (IRE)"],
    "Mathematics": ["Principal Mathematics"],
    "Literature": ["Literature in English"],
    "Art and Design": ["Art & Design", "Fine Art"],
    "Entrepreneurship Education": ["Entrepreneurship"],
    "Foods & Nutrition": ["Foods and Nutrition"],
}


@transaction.atomic
def load_advanced_subjects():
    # Serialize repeated catalogue loads without changing existing identities.
    period = AcademicPeriod.load()
    AcademicPeriod.objects.select_for_update().get(pk=period.pk)
    alias = "default"
    for index, (name, category) in enumerate(SUBJECTS, 1):
        candidates = [name, *ALIASES.get(name, [])]
        subject = None
        for candidate in candidates:
            subject = Subject.objects.using(alias).filter(name__iexact=candidate).first()
            if subject is not None:
                break
        if subject:
            if subject.category == "Unclassified":
                subject.category = category
            if subject.a_level_type == "N/A":
                subject.a_level_type = "Compulsory" if name == "General Paper" else "Optional"
                subject.level = "Both" if subject.o_level_type != "N/A" else "A-Level"
            subject.save(using=alias, update_fields=["category", "a_level_type", "level"])
        else:
            code = f"NCDC-AL-{index:02}"
            if Subject.objects.using(alias).filter(subject_code=code).exists():
                raise ValueError(f"Subject code {code} is already in use; resolve the conflicting code before loading the catalogue.")
            Subject.objects.using(alias).create(name=name, category=category, subject_code=code, level="A-Level",
                o_level_type="N/A", a_level_type="Compulsory" if name == "General Paper" else "Optional",
                status="Active", description="NCDC higher-secondary menu. Configure school teaching allocations and papers separately.")
