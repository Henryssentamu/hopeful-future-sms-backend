const e=["Beginning of Term","Test","Midterm","Project","End of Term"];export{e as A};
